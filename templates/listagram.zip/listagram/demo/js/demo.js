(function ($) {
    "use strict";

$('.counter').countUp({
	  'time': 1000,
	  'delay': 10
	});
}(jQuery));
